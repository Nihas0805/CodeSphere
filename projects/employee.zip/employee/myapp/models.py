from django.db import models

class Employee(models.Model):

    emp_id=models.CharField(max_length=200)

    name=models.CharField(max_length=200)

    designation=models.CharField(max_length=200)

    department=models.CharField(max_length=200)

    salary=models.PositiveIntegerField()

    
