from django import forms

class EmployeeForm(forms.Form):

    emp_id=forms.CharField()

    name=forms.CharField()

    designation=forms.CharField()

    department=forms.CharField()

    salary=forms.IntegerField()

    