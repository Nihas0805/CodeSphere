
from django.shortcuts import render,redirect

from django.views.generic import View

from myapp.forms import EmployeeForm

from myapp.models import Employee

from django.contrib import messages

# Create your views here.

class EmployeeCreateView(View):

    def get(self,request,*args,**kwargs):

        form_instance=EmployeeForm()

        return render(request,"employe_create.html",{"form":form_instance})

    def post(self,request,*args,**kwargs):

        form_instance=EmployeeForm(request.POST)  

        if form_instance.is_valid():

            data=form_instance.cleaned_data

            Employee.objects.create(**data)

            messages.success(request,"employee has been added")

            return redirect('employee-list')

        else:

            messages.error(request,"employee can not been added")

            return render(request,"employe_create.html",{"form":form_instance})



class EmployeeListView(View):

        def get(self,request,*args,**kwargs):            

            qs=Employee.objects.all()

            return render(request,"employe_list.html",{"employee":qs})


class EmployeeDetailsView(View):

        def get(self,request,*args,**kwargs): 

            id=kwargs.get("pk")

            qs=Employee.objects.get(id=id)

            return render(request,"employe_details.html",{"employee":qs})


class EmployeeDeleteView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        qs=Employee.objects.get(id=id).delete()

        messages.error(request,"employee details deleted successfully")

        return redirect("employee-list")


class EmployeeUpdateView(View):

    def get(self,request,*args,**kwargs):

        id=kwargs.get("pk")

        emp_obj=Employee.objects.get(id=id)

        emp_dict={
            "emp_id":emp_obj.emp_id,
            "name":emp_obj.name,
            "designation":emp_obj.designation,
            "department":emp_obj.department,
            "salary":emp_obj.salary,
        }

        form_instance=EmployeeForm(initial=emp_dict)

        return render(request,'employe_edit.html',{"form":form_instance})

    def post(self,request,*args,**kwargs):

        form_instance=EmployeeForm(request.POST)

        if form_instance.is_valid():

            data=form_instance.cleaned_data

            id=kwargs.get("pk")

            Employee.objects.filter(id=id).update(**data)

            messages.success(request,"employee updated successfully")

            return redirect("employee-list")

        else:

            messages.error(request,"employee updation failed")

            return render(request,'employe_edit.html',{"form":form_instance})